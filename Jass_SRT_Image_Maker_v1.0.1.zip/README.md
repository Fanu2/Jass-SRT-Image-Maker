# Jass SRT Image Maker v1.0.1

A standalone PySide6 application for turning SRT subtitle lines into beautiful PNG cards.

## v1.0.1 UI Fix

- Prominent **📂 SELECT SRT FILE** button in the left panel
- High-visibility toolbar buttons
- Improved dark-theme button and input contrast

## Features

- Load and edit SRT files
- Live preview
- 10 visual presets:
  - Romantic Rose
  - Rose Garden
  - Golden Sunset
  - Midnight Love
  - Purple Dream
  - Stardust
  - Elegant Gold
  - Passion
  - Soft Blossom
  - Cinematic
- Multi-colour gradient backgrounds
- Soft light pools and sheen
- Gradient text
- Outline, shadow and glow
- Font selection
- Text size, bold and italic
- Top / center / bottom placement
- Translucent rounded text card
- Hearts, flowers, stars, sparkles, sunset and gold decorations
- Decoration strength control
- Portrait, landscape and square canvas presets
- Custom canvas dimensions
- Render current subtitle
- Batch render entire SRT
- Save edited SRT
- No external assets required

## Windows installation

Open PowerShell in this folder:

```powershell
py -m pip install PySide6
py jass_srt_image_maker.py
```

## Suggested workflow

1. Click **Open SRT**.
2. Select a subtitle line.
3. Choose a preset.
4. Adjust font, colours, position and decorations.
5. Preview the design.
6. Click **Render All** to create a numbered PNG sequence.

The PNG sequence can later be used by FFmpeg, a video editor, or Jass Subtitle Studio.

## Project philosophy

This is intentionally a separate companion application. It does not modify Jass Subtitle Studio v1.2 Simple Pro.
